Burger Hunger Icons for 1.18.3
Made by Gear/Greebo
It's not complicated